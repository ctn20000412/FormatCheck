#!/usr/bin/env python3
"""
Comprehensive Word Document Reader
Extracts text, formulas (OMML→LaTeX), and images from .docx files.

Usage:
    python read_docx.py <input.docx> <output_dir>

Outputs:
    <output_dir>/content.md        — Full text with LaTeX formulas
    <output_dir>/images/           — All embedded images
    <output_dir>/pages/            — Per-page rendered images (if PDF conversion available)
    <output_dir>/metadata.json     — Document metadata summary
"""

import sys
import os
import json
import zipfile
import shutil
import subprocess
import re
import xml.etree.ElementTree as ET
from pathlib import Path

# OMML namespace map
NS = {
    'w': 'http://schemas.openxmlformats.org/wordprocessingml/2006/main',
    'm': 'http://schemas.openxmlformats.org/officeDocument/2006/math',
    'r': 'http://schemas.openxmlformats.org/officeDocument/2006/relationships',
    'wp': 'http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing',
    'a': 'http://schemas.openxmlformats.org/drawingml/2006/main',
    'pic': 'http://schemas.openxmlformats.org/drawingml/2006/picture',
}


def extract_images(docx_path: str, output_dir: str) -> list:
    """Extract all images from the docx ZIP archive."""
    images_dir = os.path.join(output_dir, "images")
    os.makedirs(images_dir, exist_ok=True)
    extracted = []
    with zipfile.ZipFile(docx_path, 'r') as z:
        for name in z.namelist():
            if name.startswith("word/media/"):
                basename = os.path.basename(name)
                target = os.path.join(images_dir, basename)
                with z.open(name) as src, open(target, 'wb') as dst:
                    dst.write(src.read())
                extracted.append(basename)
    return extracted


def omml_to_latex(elem) -> str:
    """Convert an OMML <m:oMath> element to approximate LaTeX."""
    tag = elem.tag.split('}')[-1] if '}' in elem.tag else elem.tag

    if tag == 'r':  # Run — extract text
        texts = []
        for t in elem.findall('.//m:t', NS):
            if t.text:
                texts.append(t.text)
        return ''.join(texts)

    elif tag == 'f':  # Fraction
        num = elem.find('m:num', NS)
        den = elem.find('m:den', NS)
        n = omml_children_to_latex(num) if num is not None else ''
        d = omml_children_to_latex(den) if den is not None else ''
        return f'\\frac{{{n}}}{{{d}}}'

    elif tag == 'rad':  # Radical
        deg = elem.find('m:deg', NS)
        base = elem.find('m:e', NS)
        b = omml_children_to_latex(base) if base is not None else ''
        d = omml_children_to_latex(deg) if deg is not None else ''
        if d and d.strip():
            return f'\\sqrt[{d}]{{{b}}}'
        return f'\\sqrt{{{b}}}'

    elif tag == 'sSup':  # Superscript
        base = elem.find('m:e', NS)
        sup = elem.find('m:sup', NS)
        b = omml_children_to_latex(base) if base is not None else ''
        s = omml_children_to_latex(sup) if sup is not None else ''
        return f'{b}^{{{s}}}'

    elif tag == 'sSub':  # Subscript
        base = elem.find('m:e', NS)
        sub = elem.find('m:sub', NS)
        b = omml_children_to_latex(base) if base is not None else ''
        s = omml_children_to_latex(sub) if sub is not None else ''
        return f'{b}_{{{s}}}'

    elif tag == 'sSubSup':  # Sub-Superscript
        base = elem.find('m:e', NS)
        sub = elem.find('m:sub', NS)
        sup = elem.find('m:sup', NS)
        b = omml_children_to_latex(base) if base is not None else ''
        sb = omml_children_to_latex(sub) if sub is not None else ''
        sp = omml_children_to_latex(sup) if sup is not None else ''
        return f'{b}_{{{sb}}}^{{{sp}}}'

    elif tag == 'nary':  # N-ary (sum, integral, product)
        sub = elem.find('m:sub', NS)
        sup = elem.find('m:sup', NS)
        e = elem.find('m:e', NS)
        # Try to get the operator character
        chr_elem = elem.find('.//m:naryPr/m:chr', NS)
        op = '\\int'
        if chr_elem is not None:
            c = chr_elem.get(f'{{{NS["m"]}}}val', chr_elem.get('val', ''))
            if '∑' in c or 'sum' in c.lower():
                op = '\\sum'
            elif '∏' in c or 'prod' in c.lower():
                op = '\\prod'
        sb = omml_children_to_latex(sub) if sub is not None else ''
        sp = omml_children_to_latex(sup) if sup is not None else ''
        body = omml_children_to_latex(e) if e is not None else ''
        return f'{op}_{{{sb}}}^{{{sp}}} {body}'

    elif tag == 'd':  # Delimiter (parentheses, brackets)
        children_content = []
        for de in elem.findall('m:e', NS):
            children_content.append(omml_children_to_latex(de))
        # Check delimiter characters
        dPr = elem.find('m:dPr', NS)
        beg, end = '(', ')'
        if dPr is not None:
            bc = dPr.find('m:begChr', NS)
            ec = dPr.find('m:endChr', NS)
            if bc is not None:
                beg = bc.get(f'{{{NS["m"]}}}val', bc.get('val', '('))
            if ec is not None:
                end = ec.get(f'{{{NS["m"]}}}val', ec.get('val', ')'))
        sep = ', '.join(children_content)
        return f'\\left{beg}{sep}\\right{end}'

    elif tag in ('e', 'num', 'den', 'deg', 'sub', 'sup', 'oMath'):
        return omml_children_to_latex(elem)

    else:
        # Generic fallback: recurse into children
        return omml_children_to_latex(elem)


def omml_children_to_latex(elem) -> str:
    """Convert all children of an element to LaTeX."""
    if elem is None:
        return ''
    parts = []
    for child in elem:
        parts.append(omml_to_latex(child))
    if not parts and elem.text:
        return elem.text
    return ''.join(parts)


def pandoc_convert(docx_path: str, output_dir: str) -> str:
    """Use pandoc to convert docx to markdown with math."""
    md_path = os.path.join(output_dir, "content_pandoc.md")
    try:
        subprocess.run([
            'pandoc', docx_path,
            '-o', md_path,
            '--wrap=none',
            '--extract-media', os.path.join(output_dir, 'pandoc_media')
        ], check=True, capture_output=True, text=True)
        return md_path
    except (subprocess.CalledProcessError, FileNotFoundError) as e:
        print(f"  [INFO] pandoc conversion skipped: {e}")
        return ""


def pdf_to_images(docx_path: str, output_dir: str) -> list:
    """Convert docx→pdf→images for visual inspection."""
    pages_dir = os.path.join(output_dir, "pages")
    os.makedirs(pages_dir, exist_ok=True)
    pdf_path = os.path.join(output_dir, "document.pdf")

    # Try LibreOffice conversion
    try:
        soffice_script = os.path.join(
            os.path.dirname(__file__), '..', '..', 'docx', 'scripts', 'office', 'soffice.py'
        )
        if os.path.exists(soffice_script):
            subprocess.run([
                sys.executable, soffice_script,
                '--headless', '--convert-to', 'pdf',
                '--outdir', output_dir,
                docx_path
            ], check=True, capture_output=True, text=True)
        else:
            # Direct soffice call
            subprocess.run([
                'soffice', '--headless', '--convert-to', 'pdf',
                '--outdir', output_dir, docx_path
            ], check=True, capture_output=True, text=True)
    except (subprocess.CalledProcessError, FileNotFoundError):
        print("  [INFO] PDF conversion not available (LibreOffice not found)")
        return []

    # Convert PDF pages to images
    if not os.path.exists(pdf_path):
        # LibreOffice names output after the input file
        base = os.path.splitext(os.path.basename(docx_path))[0]
        alt_pdf = os.path.join(output_dir, f"{base}.pdf")
        if os.path.exists(alt_pdf):
            pdf_path = alt_pdf
        else:
            return []

    try:
        subprocess.run([
            'pdftoppm', '-jpeg', '-r', '200',
            pdf_path, os.path.join(pages_dir, 'page')
        ], check=True, capture_output=True, text=True)
        pages = sorted(os.listdir(pages_dir))
        return pages
    except (subprocess.CalledProcessError, FileNotFoundError):
        # Try Pillow/PyMuPDF as fallback
        try:
            import fitz  # PyMuPDF
            doc = fitz.open(pdf_path)
            pages = []
            for i, page in enumerate(doc):
                pix = page.get_pixmap(dpi=200)
                img_path = os.path.join(pages_dir, f"page-{i+1:03d}.jpg")
                pix.save(img_path)
                pages.append(f"page-{i+1:03d}.jpg")
            return pages
        except ImportError:
            print("  [INFO] Page image conversion not available (no pdftoppm or PyMuPDF)")
            return []


def parse_document_xml(docx_path: str, output_dir: str) -> str:
    """Parse document.xml to extract text with inline LaTeX formulas."""
    with zipfile.ZipFile(docx_path, 'r') as z:
        doc_xml = z.read('word/document.xml')

    root = ET.fromstring(doc_xml)
    body = root.find('.//w:body', NS)
    if body is None:
        return ""

    lines = []
    for para in body:
        ptag = para.tag.split('}')[-1] if '}' in para.tag else para.tag
        if ptag != 'p':
            # Handle tables, etc.
            if ptag == 'tbl':
                lines.append('\n[TABLE]\n')
            continue

        # Detect heading level
        pStyle = para.find('.//w:pPr/w:pStyle', NS)
        heading_prefix = ""
        if pStyle is not None:
            style_val = pStyle.get(f'{{{NS["w"]}}}val', '')
            heading_match = re.match(r'[Hh]eading\s*(\d+)', style_val)
            if heading_match:
                level = int(heading_match.group(1))
                heading_prefix = '#' * level + ' '

        parts = []
        for child in para:
            ctag = child.tag.split('}')[-1] if '}' in child.tag else child.tag

            if ctag == 'r':  # Regular run
                for t in child.findall('w:t', NS):
                    if t.text:
                        parts.append(t.text)

            elif ctag == 'oMathPara' or ctag == 'oMath':
                # Math block or inline
                latex = omml_to_latex(child)
                if ctag == 'oMathPara':
                    parts.append(f' $${latex}$$ ')
                else:
                    parts.append(f' ${latex}$ ')

            elif ctag == 'hyperlink':
                for t in child.findall('.//w:t', NS):
                    if t.text:
                        parts.append(t.text)

        # Also check for math elements nested inside runs
        for omath in para.findall('.//m:oMath', NS):
            # Skip if already processed at paragraph level
            parent = None
            for p in para:
                if omath in list(p.iter()):
                    parent = p
                    break
            if parent is not None:
                ptag2 = parent.tag.split('}')[-1] if '}' in parent.tag else parent.tag
                if ptag2 not in ('oMath', 'oMathPara'):
                    latex = omml_to_latex(omath)
                    parts.append(f' ${latex}$ ')

        line = heading_prefix + ''.join(parts).strip()
        if line:
            lines.append(line)
        else:
            lines.append('')  # Preserve blank paragraphs

    return '\n\n'.join(lines)


def main():
    if len(sys.argv) < 3:
        print("Usage: python read_docx.py <input.docx> <output_dir>")
        sys.exit(1)

    docx_path = os.path.abspath(sys.argv[1])
    output_dir = os.path.abspath(sys.argv[2])

    if not os.path.exists(docx_path):
        print(f"Error: File not found: {docx_path}")
        sys.exit(1)

    os.makedirs(output_dir, exist_ok=True)

    print(f"📄 Reading: {docx_path}")
    print(f"📁 Output:  {output_dir}")
    print()

    # Step 1: Pandoc conversion (text + math → Markdown)
    print("Step 1/4: Pandoc conversion (text + LaTeX math)...")
    pandoc_md = pandoc_convert(docx_path, output_dir)
    if pandoc_md:
        print(f"  ✅ Saved: {pandoc_md}")
    else:
        print("  ⚠️  Pandoc not available, using XML parser fallback")

    # Step 2: XML parsing (OMML → LaTeX, preserves formula structure)
    print("Step 2/4: XML parsing (OMML formulas → LaTeX)...")
    xml_content = parse_document_xml(docx_path, output_dir)
    xml_md_path = os.path.join(output_dir, "content.md")
    with open(xml_md_path, 'w', encoding='utf-8') as f:
        f.write(xml_content)
    print(f"  ✅ Saved: {xml_md_path}")

    # Step 3: Extract images
    print("Step 3/4: Extracting images...")
    images = extract_images(docx_path, output_dir)
    print(f"  ✅ Extracted {len(images)} images: {images}")

    # Step 4: PDF → page images (for visual inspection)
    print("Step 4/4: Generating page images for visual inspection...")
    pages = pdf_to_images(docx_path, output_dir)
    if pages:
        print(f"  ✅ Generated {len(pages)} page images")
    else:
        print("  ⚠️  Page image generation skipped (optional dependency missing)")

    # Write metadata summary
    metadata = {
        "source": os.path.basename(docx_path),
        "output_dir": output_dir,
        "pandoc_available": bool(pandoc_md),
        "pandoc_output": pandoc_md if pandoc_md else None,
        "xml_output": xml_md_path,
        "images_extracted": images,
        "page_images": pages,
        "files_generated": []
    }

    # List all generated files
    for root_dir, dirs, files in os.walk(output_dir):
        for f in files:
            rel = os.path.relpath(os.path.join(root_dir, f), output_dir)
            metadata["files_generated"].append(rel)

    meta_path = os.path.join(output_dir, "metadata.json")
    with open(meta_path, 'w', encoding='utf-8') as f:
        json.dump(metadata, f, indent=2, ensure_ascii=False)
    print(f"\n📋 Metadata: {meta_path}")

    print("\n" + "=" * 60)
    print("✅ Document reading complete!")
    print(f"   📝 Text + formulas: {xml_md_path}")
    if pandoc_md:
        print(f"   📝 Pandoc output:   {pandoc_md}")
    if images:
        print(f"   🖼️  Images:          {os.path.join(output_dir, 'images')}/")
    if pages:
        print(f"   📄 Page renders:    {os.path.join(output_dir, 'pages')}/")
    print("=" * 60)


if __name__ == '__main__':
    main()
