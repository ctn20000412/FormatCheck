# 📄 docx-reader-skill

**Comprehensive Word Document (.docx) Reader for AI Agents**

**面向 AI 智能体的 Word 文档全量读取技能**

---

## English

### Overview

`docx-reader-skill` is a plug-and-play skill that enables AI coding agents to **fully read** Word documents, including:

- ✅ **Body text** — paragraphs, headings, hyperlinks
- ✅ **Mathematical formulas** — Office Math (OMML) auto-converted to LaTeX
- ✅ **Embedded images** — extracted from the docx ZIP archive
- ✅ **Page renders** — optional PDF→JPEG conversion for visual layout inspection

### How It Works

The skill implements a **4-step pipeline**:

```
┌─────────────┐     ┌─────────────┐     ┌─────────────┐     ┌─────────────┐
│  1. Pandoc   │────▶│ 2. XML Parse │────▶│ 3. Images    │────▶│ 4. Pages    │
│  .docx → .md │     │ OMML → LaTeX │     │ word/media/  │     │ PDF → JPEG  │
└─────────────┘     └─────────────┘     └─────────────┘     └─────────────┘
```

| Step | Output | Purpose |
|------|--------|---------|
| Pandoc | `content_pandoc.md` | Text + math via pandoc (best for headings/tables) |
| XML Parser | `content.md` | Text + OMML→LaTeX formulas (best for equation fidelity) |
| Image Extraction | `images/` | All embedded PNG/JPEG/EMF files |
| Page Rendering | `pages/` | Per-page JPEG for visual verification |

### Quick Start

```bash
python scripts/read_docx.py <input.docx> <output_dir>
```

**Example:**

```bash
python scripts/read_docx.py paper.docx paper_extracted/
```

Output:
```
paper_extracted/
├── content.md           # Full text with $LaTeX$ formulas
├── content_pandoc.md    # Pandoc-converted markdown
├── images/              # All embedded images
│   ├── image1.png
│   └── image2.jpeg
├── pages/               # Rendered page images (optional)
│   ├── page-001.jpg
│   └── page-002.jpg
└── metadata.json        # Extraction summary
```

### Formula Conversion Examples

| Word Formula (OMML) | LaTeX Output |
|---|---|
| Fraction | `\frac{α_1}{2(α_2 + γA)}` |
| Superscript | `P^{2}` |
| Subscript | `λ_{0}` |
| Summation | `\sum_{i=1}^{n} x_i` |
| Integral | `\int_{0}^{1} f(x) dx` |
| Delimiters | `\left( \frac{a}{b} \right)` |

### Dependencies

| Tool | Required | Install |
|------|----------|---------|
| Python 3.x | ✅ | Pre-installed |
| pandoc | ✅ | `winget install JohnMacFarlane.Pandoc` |
| python-docx | Optional | `pip install python-docx` |
| Pillow | Optional | `pip install Pillow` |
| LibreOffice | Optional | For PDF conversion |
| Poppler (pdftoppm) | Optional | For page image rendering |

### License

MIT License — free to use, modify, and distribute.

---

## 中文说明

### 概述

`docx-reader-skill` 是一个即插即用的 AI 技能插件，使 AI 编程助手能够**完整读取** Word 文档的全部内容，包括：

- ✅ **正文文本** — 段落、标题、超链接
- ✅ **数学公式** — Office 数学公式（OMML）自动转换为 LaTeX
- ✅ **嵌入图片** — 从 docx 压缩包中提取所有图片文件
- ✅ **页面渲染** — 可选的 PDF→JPEG 转换，用于排版效果审查

### 工作原理

本技能采用 **4 步流水线**架构：

| 步骤 | 输出文件 | 用途 |
|------|----------|------|
| 1. Pandoc 转换 | `content_pandoc.md` | 文本 + 数学公式（标题/表格识别更好） |
| 2. XML 解析 | `content.md` | 文本 + OMML→LaTeX 公式（公式精度更高） |
| 3. 图片提取 | `images/` | 提取所有嵌入的 PNG/JPEG/EMF 文件 |
| 4. 页面渲染 | `pages/` | 逐页 JPEG 截图，用于视觉审查 |

### 快速开始

```bash
python scripts/read_docx.py <输入文件.docx> <输出目录>
```

**示例：**

```bash
python scripts/read_docx.py 论文.docx 论文提取结果/
```

### 公式转换示例

| Word 中的公式 | 转换为 LaTeX |
|---|---|
| 分数 | `\frac{α_1}{2(α_2 + γA)}` |
| 上标 | `P^{2}` |
| 下标 | `λ_{0}` |
| 求和 | `\sum_{i=1}^{n} x_i` |
| 积分 | `\int_{0}^{1} f(x) dx` |
| 括号 | `\left( \frac{a}{b} \right)` |

### 依赖项

| 工具 | 是否必需 | 安装方式 |
|------|----------|----------|
| Python 3.x | ✅ 必需 | 系统预装 |
| pandoc | ✅ 必需 | `winget install JohnMacFarlane.Pandoc` |
| python-docx | 可选 | `pip install python-docx` |
| Pillow | 可选 | `pip install Pillow` |
| LibreOffice | 可选 | 用于 PDF 转换 |
| Poppler | 可选 | 用于页面图片渲染 |

### 适用场景

- 🎓 **学术论文审阅** — 完整提取含复杂公式的论文内容
- 📊 **报告分析** — 批量提取 Word 报告中的文字和图表
- 🔍 **文档对比** — 提取为 Markdown 后方便进行 diff 对比
- 🤖 **AI 辅助写作** — 让 AI 助手能够理解并修改 Word 文档中的数学内容

### 已知限制

- MathType 公式（以 OLE 对象/图片形式嵌入的）无法转换为 LaTeX，但会作为图片被提取到 `images/` 目录
- 部分复杂嵌套的 OMML 公式可能转换不够精确，建议与 `content_pandoc.md` 交叉核对
- 页面渲染功能需要安装 LibreOffice 和 Poppler

---

**Made with ❤️ by [keypeo](https://github.com/keypeo)**
